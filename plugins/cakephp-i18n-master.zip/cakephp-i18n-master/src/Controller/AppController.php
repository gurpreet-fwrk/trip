<?php

namespace MultiLanguage\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
